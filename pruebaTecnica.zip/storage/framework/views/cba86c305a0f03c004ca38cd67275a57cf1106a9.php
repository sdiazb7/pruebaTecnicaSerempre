<?php $__env->startSection('title', "Crear Cliente"); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h4 class="card-header">Crear cliente</h4>
        <div class="card-body">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <h6>Por favor corrige los errores debajo:</h6>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(url('clients')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <label for="name">Nombre:</label>
                    <input type="text" class="form-control" name="name" id="name"  value="<?php echo e(old('name')); ?>" placeholder="Nombre">
                </div>

                  <label for="city">Ciudad:</label>
			<select name="city" class="form-control" style="margin-bottom:2em">
                <option value="0">Seleccione ciudad</option>
             <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
            </select>

                <button type="submit" class="btn btn-primary">Registrar cliente</button>
                <a href="<?php echo e(route('client.index')); ?>" class="btn btn-link">Regresar al listado de usuarios</a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pruebaTecnica\resources\views/client/create.blade.php ENDPATH**/ ?>