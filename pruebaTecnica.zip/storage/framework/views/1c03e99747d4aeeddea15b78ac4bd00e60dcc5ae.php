<?php $__env->startSection('title', "Cliente {$client->id}"); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h4 class="card-header">Informaciòn del cliente</h4>
        <div class="card-body">
    <p>Codigo de cliente:<?php echo e($client->id); ?><p>
    <p>Nombre del usuario: <?php echo e($client->name); ?></p>
    <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p>Ciudad: <?php echo e($c->name); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <p>
        <a href="<?php echo e(route('client.index')); ?>">Regresar al listado de usuarios</a>
    </p>
	</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pruebaTecnica\resources\views/client/show.blade.php ENDPATH**/ ?>