<?php $__env->startSection('title', "Ciudad {$cities->id}"); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h4 class="card-header">Informaciòn del cliente</h4>
        <div class="card-body">
    <p>Codigo de ciudad: <?php echo e($cities->id); ?></p>

    <p>Nombre de la ciudad: <?php echo e($cities->name); ?></p>
    
    <p>
        <a href="<?php echo e(route('cities.index')); ?>">Regresar al listado de ciudades</a>
    </p>
	</div>
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pruebaTecnica\resources\views/cities/show.blade.php ENDPATH**/ ?>