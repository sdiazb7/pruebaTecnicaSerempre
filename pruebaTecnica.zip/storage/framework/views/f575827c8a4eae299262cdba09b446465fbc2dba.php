<?php $__env->startSection('title', "Crear usuario"); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h4 class="card-header">Editar usuario</h4>
        <div class="card-body">

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <h6>Por favor corrige los errores debajo:</h6>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(url("user/{$user->id}")); ?>">
        <?php echo e(method_field('PUT')); ?>

        <?php echo e(csrf_field()); ?>


        <label for="name">Nombre:</label>
        <input type="text" name="name" id="name" class="form-control" placeholder="Pedro Perez" value="<?php echo e(old('name', $user->name)); ?>">
        <br>
        <label for="email">Correo electrónico:</label>
        <input type="email" name="email" id="email" class="form-control" placeholder="pedro@example.com" value="<?php echo e(old('email', $user->email)); ?>">
        <br>
        <label for="password">Contraseña:</label>
        <input type="password" name="password" id="password" class="form-control"  placeholder="Mayor a 6 caracteres">
        <br>
        <button type="submit" class="btn btn-primary">Actualizar usuario</button>
    </form>

    <p>
        <a href="<?php echo e(route('users.index')); ?>">Regresar al listado de usuarios</a>
    </p>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pruebaTecnica\resources\views/users/edit.blade.php ENDPATH**/ ?>