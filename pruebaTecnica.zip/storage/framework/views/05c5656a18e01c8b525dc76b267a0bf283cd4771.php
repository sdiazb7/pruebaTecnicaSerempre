<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-end mb-3">
        <h1 class="pb-1">Listado de clientes</h1>
        <p>
            <a href="<?php echo e(route('client.create')); ?>" class="btn btn-primary">Registar Cliente</a>
        </p>
    </div>

    <?php if($client->isNotEmpty()): ?>
	
	<form action="<?php echo e(route('client.index')); ?>" method="get">
	<div class="form-row">
	<div class="col-sm-4 my-1">
	<input type="text" class="form-control" name="text" placeholder="Buscar clientes por ciudad">
	</div>
	<div class="col-auto my-l">
	<input type="submit" class="btn btn-primary" value="Buscar">
	</div>
	</form>
    <table class="table" style="margin-top:2em">
        <thead class="thead">
        <tr>
            <th scope="col">Codigo</th>
            <th scope="col">Nombre</th>
            <th scope="col">Ciudad</th>
			<th scope="col">Opciones</th>
            
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($c->id); ?></th>
            <td><?php echo e($c->name); ?></td>
            <td><?php echo e($c->city); ?></td>
            <td>
                <form action="<?php echo e(route('client.destroy', $c)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <a href="<?php echo e(route('client.show', $c)); ?>" class="btn btn-link"><span class="oi oi-eye"></span></a>
                    <a href="<?php echo e(route('client.edit', $c)); ?>" class="btn btn-link"><span class="oi oi-pencil"></span></a>
                    <button type="submit" class="btn btn-link"><span class="oi oi-trash"></span></button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
		<?php echo $client->render(); ?>

    <?php else: ?>
        <p>No hay usuarios registrados.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pruebaTecnica\resources\views/client/index.blade.php ENDPATH**/ ?>