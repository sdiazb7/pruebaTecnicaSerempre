<?php $__env->startSection('title', "Usuario {$user->id}"); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h4 class="card-header">Editar usuario</h4>
        <div class="card-body">
    <p>Codigo Usuario: <?php echo e($user->id); ?><p>

    <p>Nombre del usuario: <?php echo e($user->name); ?></p>
    <p>Correo electrónico: <?php echo e($user->email); ?></p>

    <p>
        <a href="<?php echo e(route('users.index')); ?>">Regresar al listado de usuarios</a>
    </p>
	</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pruebaTecnica\resources\views/users/show.blade.php ENDPATH**/ ?>