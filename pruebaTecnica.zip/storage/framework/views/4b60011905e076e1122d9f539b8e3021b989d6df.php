<?php $__env->startSection('title', 'Ciudad'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-end mb-3">
        <h1 class="pb-1"><?php echo e($title); ?></h1>
        <p>
            <a href="<?php echo e(route('cities.create')); ?>" class="btn btn-primary">Registrar ciudad</a>
        </p>
    </div>

    <?php if($cities->isNotEmpty()): ?>
    <table class="table">
        <thead class="thead">
        <tr>
            <th scope="col">Codigo</th>
            <th scope="col">Nombre</th>
            <th scope="col">Opciones</th>
            
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($city->id); ?></th>
            <td><?php echo e($city->name); ?></td>
          
            <td>
                <form action="<?php echo e(route('cities.destroy', $city)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <a href="<?php echo e(route('cities.show', $city)); ?>" class="btn btn-link"><span class="oi oi-eye"></span></a>
                    <a href="<?php echo e(route('cities.edit', $city)); ?>" class="btn btn-link"><span class="oi oi-pencil"></span></a>
                    <button type="submit" class="btn btn-link"><span class="oi oi-trash"></span></button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
		<?php echo $cities->render(); ?>

    <?php else: ?>
        <p>No hay usuarios registrados.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pruebaTecnica\resources\views/cities/index.blade.php ENDPATH**/ ?>