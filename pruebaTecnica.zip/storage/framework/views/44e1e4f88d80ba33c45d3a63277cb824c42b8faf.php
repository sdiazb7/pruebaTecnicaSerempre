<?php $__env->startSection('title', "Editar Ciudad"); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h4 class="card-header">Editar ciudad</h4>
        <div class="card-body">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <h6>Por favor corrige los errores debajo:</h6>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(url("cities/{$cities->id}")); ?>">
        <?php echo e(method_field('PUT')); ?>

        <?php echo e(csrf_field()); ?>


        <label for="name">Nombre:</label>
        <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name', $cities->name)); ?>" placeholder="Name">
        <br>
        <button type="submit" class="btn btn-primary">Actualizar ciudad</button>
    </form>

    <p>
        <a href="<?php echo e(route('cities.index')); ?>">Regresar al listado de cliente</a>
    </p>
	</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pruebaTecnica\resources\views/cities/edit.blade.php ENDPATH**/ ?>