<?php

namespace App\Http\Controllers;
use App\Models\Cities;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class CitiesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
	
    public function index()
    {

        $title = 'Listado de usuarios';
		$cities = Cities::orderBy('id','DESC')->paginate(5);

        return view('cities.index', compact('title', 'cities'));
    }

    public function show(Cities $cities)
    {
        return view('cities.show', compact('cities'));
    }

    public function create()
    {
        return view('cities.create');
    }

    public function store()
    {
		
		
	 $data = request()->validate([
            'name' => 'required',
            
        ], [
            'name.required' => 'El campo nombre es obligatorio'
        ]);
		
        Cities::create([
             
            'name' => $data['name']
        ]);

        return redirect()->route('cities.index');
    }

    public function edit(Cities $cities)
    {
        return view('cities.edit', ['cities' => $cities]);
    }

    public function update(Cities $cities)
    {
		
		$data = request()->validate([
		
            'name' => 'required'
          
        ]);

        $cities->update($data);

        return redirect()->route('cities.index', ['cities' => $cities]);
    }

    function destroy(Cities $cities)
    {
        $cities->delete();

        return redirect()->route('cities.index');
    }
}