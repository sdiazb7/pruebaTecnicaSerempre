<?php

namespace Database\Seeders;
use Faker\Factory as Faker;
use Illuminate\Database\Seeder;

class CitiesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
      public function run(){
		  
		  
		  $cities = array(
          ['id' => '1', 'name' => 'Cali', 'created_at' => date('Y-m-d H:m:s') ,'updated_at' => date('Y-m-d H:m:s')],
          ['id' => '2', 'name' => 'Bogota', 'created_at' => date('Y-m-d H:m:s') ,'updated_at' => date('Y-m-d H:m:s')],
		  ['id' => '3', 'name' => 'Medellin', 'created_at' => date('Y-m-d H:m:s') ,'updated_at' => date('Y-m-d H:m:s')],
		  ['id' => '4', 'name' => 'Barranquilla', 'created_at' => date('Y-m-d H:m:s') ,'updated_at' => date('Y-m-d H:m:s')],
		  ['id' => '5', 'name' => 'Cartagena', 'created_at' => date('Y-m-d H:m:s') ,'updated_at' => date('Y-m-d H:m:s')],
		  ['id' => '6', 'name' => 'Neiva', 'created_at' => date('Y-m-d H:m:s') ,'updated_at' => date('Y-m-d H:m:s')],
		  ['id' => '7', 'name' => 'Ibague', 'created_at' => date('Y-m-d H:m:s') ,'updated_at' => date('Y-m-d H:m:s')],
		  ['id' => '8', 'name' => 'Cartagena', 'created_at' => date('Y-m-d H:m:s') ,'updated_at' => date('Y-m-d H:m:s')],
		  ['id' => '9', 'name' => 'Cali', 'created_at' => date('Y-m-d H:m:s') ,'updated_at' => date('Y-m-d H:m:s')],
		  ['id' => '10', 'name' => 'Villavicencio', 'created_at' => date('Y-m-d H:m:s') ,'updated_at' => date('Y-m-d H:m:s')],
		  );
		  
            $faker = Faker::create();
            \DB::table("cities")->insert($cities);
            
      }
}
