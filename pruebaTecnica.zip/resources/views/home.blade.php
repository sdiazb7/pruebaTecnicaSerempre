@extends('layout')

@section('content')
 


    
	
	<div class="container">
	<div class="row">
	
	<!--team-1-->
	<div class="col-lg-12">
	
	
	
	<h1 class="text-center">Inicio</h1>

	
	
	</div>
	
	
	</div>
	</div>
	
@endsection
